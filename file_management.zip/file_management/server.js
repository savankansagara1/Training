const express = require("express");
const fs = require("fs");
const multer = require("multer");
const app = express();
const path = require("path")

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

// File upload setup
const storage = multer.diskStorage({
  destination: "./uploads",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage });

// CSV file path
const FILE = "data.csv";

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// CREATE
app.post("/add", upload.single("file"), (req, res) => {
  const text = req.body.text;
  const file = req.file.filename;
  const id = Date.now();

  const row = `${id},${text},${file}\n`; 

  fs.appendFileSync(FILE, row);
  res.send("Data added");
});

// READ
app.get("/data", (req, res) => {
  const data = fs.readFileSync(FILE, "utf-8");
  res.send(data);
});

// UPDATE
app.post("/update/:id", upload.single("file"), (req, res) => {
  const id = req.params.id;
  const text = req.body.text;
  const file = req.file ? req.file.filename : "";

  let data = fs.readFileSync(FILE, "utf-8").split("\n");

  data = data.map((row) => {
    let cols = row.split(",");
    if (cols[0] === id) {
      return `${id},${text},${file}`;
    }
    return row;
  });

  fs.writeFileSync(FILE, data.join("\n"));
  res.send("Updated");
});

// DELETE
app.delete("/delete/:id", (req, res) => {
  const id = req.params.id;

  let data = fs.readFileSync(FILE, "utf-8").split("\n");

  data = data.filter((row) => {
    return row.split(",")[0] !== id;
  });

  fs.writeFileSync(FILE, data.join("\n"));
  res.send("Deleted");
});

app.listen(3000, () => console.log("Server running on 3000"));