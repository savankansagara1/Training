const express = require("express");
const app = express();
const port = process.env.PORT || 3000;
const dbconn = require("./config/db");

app.set("view engine", "ejs");

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/",(req,res)=>{
  res.render("index")
})

app.post("/",(req,res)=>{
  console.log(req.body);
})

// Routes
app.get("/gender", (req, res) => {
  const query =
    `SELECT s.select_id, s.field_name, s.s_html_tag, s.html_name, s.html_id, o.html_tag, o.html_type, o.html_value, 
     o.html_label, parent_id FROM select_master s JOIN option_master o ON s.select_id = o.select_id where field_name = "gender";`
  dbconn.query(query,(err,result)=>{
    if (err) {
        console.log(err)
    }else{
        // console.log(result)
        res.send(result)
        //  res.render("index", {data: result});
    }
  });

});

app.get("/relationship",(req,res)=>{
  const query =   `SELECT s.select_id, s.field_name, s.s_html_tag, s.html_name, s.html_id, o.html_tag, o.html_type, o.html_value, 
     o.html_label, parent_id FROM select_master s JOIN option_master o ON s.select_id = o.select_id where field_name = "relationship_status";`
     dbconn.query(query,(err,result)=>{
      if(err){
        return console.log(err);
      }else{
        // console.log(result);
         return res.send(result);
      }
     })
})

app.get("/department",(req,res)=>{
  const query =   `SELECT s.select_id, s.field_name, s.s_html_tag, s.html_name, s.html_id, o.html_tag, o.html_type, o.html_value, 
     o.html_label, parent_id FROM select_master s JOIN option_master o ON s.select_id = o.select_id where field_name = "department";`
     dbconn.query(query,(err,result)=>{
      if(err){
        return console.log(err);
      }else{
        // console.log(result);
         return res.send(result);
      }
     })
})

app.get("/language",(req,res)=>{
const query =   `SELECT s.select_id, s.field_name, s.s_html_tag, s.html_name, s.html_id, o.html_tag, o.html_type, o.html_value, 
     o.html_label, parent_id FROM select_master s JOIN option_master o ON s.select_id = o.select_id where field_name = "Language";`

dbconn.query(query,(err,result)=>{
      if(err){
        return console.log(err);
      }else{
        // console.log(result);
         return res.send(result);
      }
     })
    })

    app.get("/technology",(req,res)=>{
      const query = `SELECT s.select_id, s.field_name, s.s_html_tag, s.html_name, s.html_id, o.html_tag, o.html_type, o.html_value, 
     o.html_label, parent_id FROM select_master s JOIN option_master o ON s.select_id = o.select_id where field_name = "Technology";`

     dbconn.query(query,(err,result)=>{
      if(err){
        return console.log(err);
      }else{
        // console.log(result);
         return res.send(result);
      }
     })
    })

// Start server
app.listen(5000, () => {
  console.log(`http://localhost:5000`);
});
